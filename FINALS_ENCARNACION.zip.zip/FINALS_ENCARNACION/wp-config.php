<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/documentation/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'finalsEncarnacion' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', '' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'mK7jlq4y4)*AN8<CN>2G8WTqu7r06x>uo|;i.fD#;%0a^ (}u-#F`HeYdLO_1Svu' );
define( 'SECURE_AUTH_KEY',  'Mzq5+)!2RhhcC1u#A_J9N}G/*U&b14?n0N~t}~6>ZKH:pR{_yEM}|n1W,OU5a<Yt' );
define( 'LOGGED_IN_KEY',    's{z$B1;_EtNj~:wK7]KDC6OF}^IJ<_$ybc_V98 Dp?.SAl Id]Slaw3};|.d/0j=' );
define( 'NONCE_KEY',        'AHg{9x/E0t(ojNwId8tkc$JF/s8Q*E4ebdP2/[?NZWF0ij;Oy`w*h37))N4*[-:e' );
define( 'AUTH_SALT',        '0Z4k6xD1+o`kJ8$<2PKe.JONAAjB}1@/ J9vPPTIXbhyle.es>O Sa.]?+8x7,gc' );
define( 'SECURE_AUTH_SALT', 'A7&C3y%WT+(4u`Jg.udNV9^6*EkE[xKNywyf][{QtZLzQiW[Gw937Ebei0!pZ2}(' );
define( 'LOGGED_IN_SALT',   '5o/g/];*rHIzN>B?j`&*/+4KW&{@*B_F9 #d>cig{gDRaOgxU U){%R#+R.?Ml|j' );
define( 'NONCE_SALT',       'e++)Oplw3CKM#KZcU?`:$btMy)`MsQjrFZ*uuuo+xbs>#{qo^GCI(QKzJk4d6{.4' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/documentation/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
